<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_View cart</name>
   <tag></tag>
   <elementGuidId>3de759ac-670a-441a-8836-ea864029cb39</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/div/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.woocommerce-message > a.button.wc-forward</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>fd40e295-8451-42f4-824d-be3dac296528</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/cart/</value>
      <webElementGuid>026e2b5f-f966-4203-a784-65f8b6bc16d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button wc-forward</value>
      <webElementGuid>d6b24db8-2c08-49cf-8478-57412af67585</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>View cart</value>
      <webElementGuid>1f565293-5754-4bb7-9cc0-df164317b690</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[@class=&quot;col-full&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;woocommerce-message&quot;]/a[@class=&quot;button wc-forward&quot;]</value>
      <webElementGuid>3b688536-c189-4cc5-8ba0-073ceda7d5e2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/div/a</value>
      <webElementGuid>9b388809-e3e9-474d-a6f1-7256e0ca52a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'View cart')])[2]</value>
      <webElementGuid>5e5bc68d-e02e-4391-b7c5-447625746caf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::a[1]</value>
      <webElementGuid>504f08e4-cedf-47b1-a557-4c69a82a9588</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FREE SHIPPING'])[1]/preceding::a[8]</value>
      <webElementGuid>828c37a2-f097-4f41-947f-f9b144d347eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Round Rattan Cane Chair | Recliner Chair for Indoor Outdoor'])[1]/preceding::a[8]</value>
      <webElementGuid>1a6c73ba-84fd-4f5c-bed6-87f53470c5db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/cart/')])[5]</value>
      <webElementGuid>f330c65d-89e2-4330-9577-c42227e494a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/a</value>
      <webElementGuid>7274936f-1214-408b-9bfc-2e749e45422e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/cart/' and (text() = 'View cart' or . = 'View cart')]</value>
      <webElementGuid>15a9ff53-7a9f-47ff-b8a2-7630e4311fd7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
