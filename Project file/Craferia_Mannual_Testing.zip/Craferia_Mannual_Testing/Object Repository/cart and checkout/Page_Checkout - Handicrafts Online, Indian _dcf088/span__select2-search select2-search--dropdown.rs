<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span__select2-search select2-search--dropdown</name>
   <tag></tag>
   <elementGuidId>108484aa-b198-4954-ad90-b3ecd2a823c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/following::span[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.select2-search.select2-search--dropdown</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a3455805-d1dd-4943-b7b6-0f1ef1ad4771</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>select2-search select2-search--dropdown</value>
      <webElementGuid>fa8c9d3f-39dd-40b2-892d-5561027d314c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;page-template-default page page-id-8 wp-custom-logo wp-embed-responsive theme-storefront woocommerce-checkout woocommerce-page woocommerce-demo-store woocommerce-js woocommerce-multi-currency-INR storefront-full-width-content storefront-secondary-navigation storefront-align-wide left-sidebar woocommerce-active&quot;]/span[@class=&quot;select2-container select2-container--default select2-container--open&quot;]/span[@class=&quot;select2-dropdown select2-dropdown--below&quot;]/span[@class=&quot;select2-search select2-search--dropdown&quot;]</value>
      <webElementGuid>d75b8b9e-230f-444d-80b3-878c4d2b1f50</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/following::span[3]</value>
      <webElementGuid>14d5c8d7-59ac-4584-8182-36481ad55f13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Afghanistan'])[3]/preceding::span[1]</value>
      <webElementGuid>b4e77064-341f-4a20-9f3a-8b477703d9fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Åland Islands'])[3]/preceding::span[1]</value>
      <webElementGuid>527f22e3-2f67-42a6-b34d-d52296e0bd5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body/span/span/span</value>
      <webElementGuid>9563c5ef-255d-4afb-8019-2f70ab89942d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
