<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Mudha furniture is available in a varie_b913fa</name>
   <tag></tag>
   <elementGuidId>40cfc6a7-8a77-41ac-ab4b-d37ceeffd6e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.term-description</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>acd72af3-aafa-43bc-bcdc-aa27d640b57c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>term-description</value>
      <webElementGuid>e7a27c23-1b65-40f0-9b71-64fa3a579183</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mudha furniture is available in a variety of styles and designs, making it a great option for any home or office. There is something special and unique about mudha furniture that makes it a great choice for both indoor and outdoor use.
It is a popular choice for indoor and outdoor use because of its durability and comfort. Mudha chairs, Mudha tables, and Mudha stools are all designed to provide a comfortable sitting experience.
</value>
      <webElementGuid>399d5da8-1d50-4a8c-99c9-e324a6641070</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]</value>
      <webElementGuid>87a4568e-c5f0-4cc6-adcf-4fb60d141975</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div</value>
      <webElementGuid>3c534ab8-ddd3-42dd-9be4-3c5f625729a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mudha'])[3]/following::div[1]</value>
      <webElementGuid>27ee18af-23f1-4137-ab4f-3d5344f0447f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::div[6]</value>
      <webElementGuid>137b0f1a-7111-44dc-812c-d6fae1029e5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(25)'])[1]/preceding::div[3]</value>
      <webElementGuid>d08ef044-a41b-41d0-a5aa-d041b7b02965</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/header/div</value>
      <webElementGuid>e7749977-ed78-4c81-87cf-f523c1744e5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Mudha furniture is available in a variety of styles and designs, making it a great option for any home or office. There is something special and unique about mudha furniture that makes it a great choice for both indoor and outdoor use.
It is a popular choice for indoor and outdoor use because of its durability and comfort. Mudha chairs, Mudha tables, and Mudha stools are all designed to provide a comfortable sitting experience.
' or . = 'Mudha furniture is available in a variety of styles and designs, making it a great option for any home or office. There is something special and unique about mudha furniture that makes it a great choice for both indoor and outdoor use.
It is a popular choice for indoor and outdoor use because of its durability and comfort. Mudha chairs, Mudha tables, and Mudha stools are all designed to provide a comfortable sitting experience.
')]</value>
      <webElementGuid>f34ca1fb-d98c-474b-bb6f-1b8d651e6f09</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
