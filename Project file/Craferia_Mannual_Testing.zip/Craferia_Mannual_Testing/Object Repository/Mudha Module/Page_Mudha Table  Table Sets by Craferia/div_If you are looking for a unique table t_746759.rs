<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_If you are looking for a unique table t_746759</name>
   <tag></tag>
   <elementGuidId>b5445795-3e6e-4158-8f40-0891244f20f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>615f9321-eef6-4c1e-bae1-c96453357474</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>term-description</value>
      <webElementGuid>162217fc-d0a2-4026-b249-21939fb11038</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>If you are looking for a unique table that will help you create the perfect setting for your living space, you should consider the mudha table. This is a table that has a unique design that allows you to create the perfect look for any type of room in your home.
A mudha table is a unique table design that is perfect for any room. It is made out of a single piece of Sarkanda and can be found in many different sizes and Quality. The table is made by sticks of Bamboo on top of each other. These sticks of bamboo and rope are stitched together to create a single piece.
It is a beautiful piece of furniture that is simple and elegant. It is also a great way to create a table that is unique, colourful and eye-catching.
</value>
      <webElementGuid>4b724bb9-babc-44b9-b22e-945b443b062a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]</value>
      <webElementGuid>96680d2b-2f3d-4cdd-817c-d1e0ac7d3517</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div</value>
      <webElementGuid>f4286e0f-701b-4fa5-9a09-751b5b93597f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mudha Table'])[3]/following::div[1]</value>
      <webElementGuid>603ff048-73a7-4455-a9d6-28342a50b2ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::div[6]</value>
      <webElementGuid>56d8c947-14eb-4038-808f-eb75b07bb734</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Handmade Bamboo Mudha for Indoor-outdoor Furniture (Set of 2)'])[1]/preceding::div[3]</value>
      <webElementGuid>adfb936c-5c60-4b18-88c7-5532e49b05ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::div[3]</value>
      <webElementGuid>887ecaea-3c49-4266-a3a1-25d7d6900468</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/header/div</value>
      <webElementGuid>d5efa77d-c89c-4532-a948-5f1b6fd92775</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'If you are looking for a unique table that will help you create the perfect setting for your living space, you should consider the mudha table. This is a table that has a unique design that allows you to create the perfect look for any type of room in your home.
A mudha table is a unique table design that is perfect for any room. It is made out of a single piece of Sarkanda and can be found in many different sizes and Quality. The table is made by sticks of Bamboo on top of each other. These sticks of bamboo and rope are stitched together to create a single piece.
It is a beautiful piece of furniture that is simple and elegant. It is also a great way to create a table that is unique, colourful and eye-catching.
' or . = 'If you are looking for a unique table that will help you create the perfect setting for your living space, you should consider the mudha table. This is a table that has a unique design that allows you to create the perfect look for any type of room in your home.
A mudha table is a unique table design that is perfect for any room. It is made out of a single piece of Sarkanda and can be found in many different sizes and Quality. The table is made by sticks of Bamboo on top of each other. These sticks of bamboo and rope are stitched together to create a single piece.
It is a beautiful piece of furniture that is simple and elegant. It is also a great way to create a table that is unique, colourful and eye-catching.
')]</value>
      <webElementGuid>85a6f45d-939a-443e-9c2d-11cf8bdff014</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
