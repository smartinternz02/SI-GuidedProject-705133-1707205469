<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Mudha chairs, also known as bamboo mudd_369b26</name>
   <tag></tag>
   <elementGuidId>bc284d9f-7abc-4a61-8b12-fd8fc4473ecc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>581d0058-5e59-4524-b55d-8d7c95073c92</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>term-description</value>
      <webElementGuid>cec5a7f8-b34a-4f66-b6af-de0f727e1395</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mudha chairs, also known as bamboo mudda chairs, are an important part of many homes and businesses. They are versatile and affordable furniture that can provide a number of different functions. From providing a functional step to reach higher shelves to providing seating in tight spaces, Mudha Chairs are a great addition to any home or business.
Offer for Chairs – Baby Chairs/Small Chairs/Medium Chairs/Large Chairs/Extra Large Chairs/Giant Chairs there is a chair for every size
</value>
      <webElementGuid>987287d9-1fb0-4138-952c-268eb6477f52</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]</value>
      <webElementGuid>285b1d60-5e7e-4a6d-85ae-d0e191d278f5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div</value>
      <webElementGuid>2088f5f4-c231-4166-b459-761982d9f669</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mudha chairs'])[3]/following::div[1]</value>
      <webElementGuid>76662499-e161-44c8-aa1a-1877ec92b2a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::div[6]</value>
      <webElementGuid>78b9848d-a439-4cb5-92f7-a5bfd7a8046a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::div[2]</value>
      <webElementGuid>d1b6532e-c750-4dc9-a7b2-0cb204d34da7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bamboo Sute Chairs for Balcony | Bamboo Mudda Chairs for indoor and outdoor'])[1]/preceding::div[3]</value>
      <webElementGuid>bc321e11-10f0-422f-990a-65984fa914b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/header/div</value>
      <webElementGuid>27bd57ee-6016-4fd8-9ca3-719bc9721af7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Mudha chairs, also known as bamboo mudda chairs, are an important part of many homes and businesses. They are versatile and affordable furniture that can provide a number of different functions. From providing a functional step to reach higher shelves to providing seating in tight spaces, Mudha Chairs are a great addition to any home or business.
Offer for Chairs – Baby Chairs/Small Chairs/Medium Chairs/Large Chairs/Extra Large Chairs/Giant Chairs there is a chair for every size
' or . = 'Mudha chairs, also known as bamboo mudda chairs, are an important part of many homes and businesses. They are versatile and affordable furniture that can provide a number of different functions. From providing a functional step to reach higher shelves to providing seating in tight spaces, Mudha Chairs are a great addition to any home or business.
Offer for Chairs – Baby Chairs/Small Chairs/Medium Chairs/Large Chairs/Extra Large Chairs/Giant Chairs there is a chair for every size
')]</value>
      <webElementGuid>37410036-513f-4cb6-9e33-419a9d388d3a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
