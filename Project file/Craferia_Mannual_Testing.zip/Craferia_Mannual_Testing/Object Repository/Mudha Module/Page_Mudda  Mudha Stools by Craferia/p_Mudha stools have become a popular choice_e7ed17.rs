<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Mudha stools have become a popular choice_e7ed17</name>
   <tag></tag>
   <elementGuidId>95f09912-b380-4973-b6f7-25d1e933d745</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>e007187e-c089-46b1-9113-87a0fabc9ab8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mudha stools have become a popular choice for those looking for furniture that is both stylish and sustainable. Made from natural materials such as rattan and bamboo, Mudda stool offer a unique and stylish look that is perfect for a variety of home decor styles.</value>
      <webElementGuid>f538d9ff-653a-48f9-9f93-9745e2fadb49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>2b35501e-2730-47a9-be02-52500a720efd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/p</value>
      <webElementGuid>8d31cb3d-63a2-4e21-9d59-c2f460893f2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mudha Stools'])[3]/following::p[1]</value>
      <webElementGuid>8388c764-26c7-405e-81d8-80c407778b93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>d4cb2489-241d-475e-96db-a46eca65e5bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor'])[1]/preceding::p[3]</value>
      <webElementGuid>219d7d83-7e3a-4bea-899a-a4ac19999957</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::p[3]</value>
      <webElementGuid>e7359229-b068-4c5e-b899-74160fd5f28f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mudha stools have become a popular choice for those looking for furniture that is both stylish and sustainable. Made from natural materials such as rattan and bamboo, Mudda stool offer a unique and stylish look that is perfect for a variety of home decor styles.']/parent::*</value>
      <webElementGuid>791e43d6-88ad-4beb-bdd1-e6de12bd12ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/p</value>
      <webElementGuid>a2605dd3-a4db-4820-8a5b-98ba2a159046</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Mudha stools have become a popular choice for those looking for furniture that is both stylish and sustainable. Made from natural materials such as rattan and bamboo, Mudda stool offer a unique and stylish look that is perfect for a variety of home decor styles.' or . = 'Mudha stools have become a popular choice for those looking for furniture that is both stylish and sustainable. Made from natural materials such as rattan and bamboo, Mudda stool offer a unique and stylish look that is perfect for a variety of home decor styles.')]</value>
      <webElementGuid>d26b01b1-8700-49e2-8643-55bde8314ef7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
