<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Mudha Table (1)</name>
   <tag></tag>
   <elementGuidId>f46c2c65-fdd1-4395-a69b-7633bd8a9cc1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li[3]/a/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>d06d5452-7bba-45e1-9ed9-e165c0400e36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-loop-category__title</value>
      <webElementGuid>aed003c8-3665-4097-914e-2e800faa47ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Mudha Table (1)		</value>
      <webElementGuid>c9ff25a9-72fc-4e07-aea5-4114415c14d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product&quot;]/a[1]/h2[@class=&quot;woocommerce-loop-category__title&quot;]</value>
      <webElementGuid>30ab6f65-d4a3-4008-9540-eab92242a030</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li[3]/a/h2</value>
      <webElementGuid>785a3bf8-772b-4a9f-bdc4-13917778151e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(3)'])[1]/following::h2[1]</value>
      <webElementGuid>62c6c8ef-7bcd-4e8b-a3cc-49645beb4430</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Benefits &amp; Features'])[1]/preceding::h2[1]</value>
      <webElementGuid>e40fde5f-a549-4805-a282-ef60e07409dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a/h2</value>
      <webElementGuid>6cc177ae-75a0-464e-905b-b1c9d865f04f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
			Mudha Table (1)		' or . = '
			Mudha Table (1)		')]</value>
      <webElementGuid>e3f0c916-2940-415e-bafd-96c8add173d8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
