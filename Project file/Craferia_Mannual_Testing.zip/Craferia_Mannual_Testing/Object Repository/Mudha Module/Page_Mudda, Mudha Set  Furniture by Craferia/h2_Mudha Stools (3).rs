<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Mudha Stools (3)</name>
   <tag></tag>
   <elementGuidId>94d23680-8089-43ee-a681-3d174903db93</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li[2]/a/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>1637c485-2cdd-4ef1-957b-c10d0ae4e386</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-loop-category__title</value>
      <webElementGuid>0151af7e-3822-4b19-b8d7-53480081a2a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Mudha Stools (3)		</value>
      <webElementGuid>3428502c-079d-4dda-9716-a18c58edf20b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product&quot;]/a[1]/h2[@class=&quot;woocommerce-loop-category__title&quot;]</value>
      <webElementGuid>1c4498c7-fe4c-4094-bef8-6b7490321c87</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li[2]/a/h2</value>
      <webElementGuid>25374438-e37b-4f79-8a8f-1a643b67f594</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(25)'])[1]/following::h2[1]</value>
      <webElementGuid>3b65fd8f-7c3f-4fa8-85b4-72cfe41b1dca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/h2</value>
      <webElementGuid>70a78c61-6ec9-4cc4-9656-ad4d17bc9746</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
			Mudha Stools (3)		' or . = '
			Mudha Stools (3)		')]</value>
      <webElementGuid>1952e855-3929-4f65-a1dc-f81003cd2e02</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
