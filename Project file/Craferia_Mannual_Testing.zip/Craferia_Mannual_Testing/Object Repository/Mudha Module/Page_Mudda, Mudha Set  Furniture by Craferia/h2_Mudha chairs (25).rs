<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Mudha chairs (25)</name>
   <tag></tag>
   <elementGuidId>39693da1-da03-4591-a5a2-5a9f95e4264b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.woocommerce-loop-category__title</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li/a/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>9ab2f67b-73c9-4310-83a1-086c8314b7d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-loop-category__title</value>
      <webElementGuid>a8f403ca-8edd-44f9-a784-99367ff35685</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Mudha chairs (25)		</value>
      <webElementGuid>23eac028-df47-485f-9eec-188b5eb5bc95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product first&quot;]/a[1]/h2[@class=&quot;woocommerce-loop-category__title&quot;]</value>
      <webElementGuid>b90fbad6-0d47-49ef-a6fa-2b804524d6af</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li/a/h2</value>
      <webElementGuid>b40603cd-15a5-4565-8e26-8f87a8c010a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mudha'])[3]/following::h2[1]</value>
      <webElementGuid>7bfdf244-d30e-4d3e-a981-94a552606ec1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::h2[1]</value>
      <webElementGuid>8037d245-b8d0-4816-aba3-b764558be9fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>539e371c-7373-44ef-b4eb-09fd70e6d370</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
			Mudha chairs (25)		' or . = '
			Mudha chairs (25)		')]</value>
      <webElementGuid>074d1e34-a709-4759-a5f2-76bd0f77a8c1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
