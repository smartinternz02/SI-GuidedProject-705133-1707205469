<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Our outdoor furniture is designed to help_5bf64e</name>
   <tag></tag>
   <elementGuidId>88973897-2ba5-42cb-a2f5-ed9facbeda03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>33260b0c-4272-4c84-b298-e37391fd4e38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Our outdoor furniture is designed to help you enjoy your outdoor living space in comfort and style. We offer dining furniture and garden outdoor furniture, all made of eco-friendly bamboo cane (sarkanda) that’s both durable and sustainable.</value>
      <webElementGuid>5e09e9bf-c2c3-4c09-9572-38616c8c7b53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>4b4c2129-7bc1-4b65-a913-2b45bba14915</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/p</value>
      <webElementGuid>fdfcfc9c-1e99-40b8-a032-b90897aa9203</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Outdoor Furniture'])[3]/following::p[1]</value>
      <webElementGuid>7cc69f5a-0b94-47c3-b811-9bdac8ae695b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::p[1]</value>
      <webElementGuid>bc5546e9-d009-4115-ada8-16fc0b13d2fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*COD is not Available on Furniture Items'])[1]/preceding::p[2]</value>
      <webElementGuid>02dcf5cb-f6d1-4275-8836-86b9f1110dca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Wooden Bench Charpai with 4 Mudda Stools for living room, balcony, garden, cafe &amp; restaurants'])[1]/preceding::p[4]</value>
      <webElementGuid>46fecd64-b99f-4f83-89ba-8feddf901ad2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Our outdoor furniture is designed to help you enjoy your outdoor living space in comfort and style. We offer dining furniture and garden outdoor furniture, all made of eco-friendly bamboo cane (sarkanda) that’s both durable and sustainable.']/parent::*</value>
      <webElementGuid>bbbe1ec4-7e44-457d-9007-8ce2595eb806</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/p</value>
      <webElementGuid>d3200814-6d47-4239-8368-152b294f3a48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Our outdoor furniture is designed to help you enjoy your outdoor living space in comfort and style. We offer dining furniture and garden outdoor furniture, all made of eco-friendly bamboo cane (sarkanda) that’s both durable and sustainable.' or . = 'Our outdoor furniture is designed to help you enjoy your outdoor living space in comfort and style. We offer dining furniture and garden outdoor furniture, all made of eco-friendly bamboo cane (sarkanda) that’s both durable and sustainable.')]</value>
      <webElementGuid>40fc5b1e-0d19-4c95-898f-e1049874dd0a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
