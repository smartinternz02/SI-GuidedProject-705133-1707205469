<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Sort by popularitySort by average ra_747407</name>
   <tag></tag>
   <elementGuidId>6482790a-dcae-4dec-a6f7-f6a69227ee38</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='orderby']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;orderby&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>655c0a9b-c3e1-4337-8f57-1bb8c04c2dce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>orderby</value>
      <webElementGuid>7c1f0667-2fcd-4172-bb04-556b9db44a2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>orderby</value>
      <webElementGuid>99a6c2ff-639d-4b04-b6cb-c25a12f70bda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Shop order</value>
      <webElementGuid>4029bcee-3f18-4ef6-9a82-38a2b4654191</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
					Sort by popularity
					Sort by average rating
					Sort by latest
					Sort by price: low to high
					Sort by price: high to low
			</value>
      <webElementGuid>b0d753b9-5b2b-4e88-99c6-550a32b56df1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/div[@class=&quot;storefront-sorting&quot;]/form[@class=&quot;woocommerce-ordering&quot;]/select[@class=&quot;orderby&quot;]</value>
      <webElementGuid>81086f57-9624-4f3d-b9d8-4fa9113aae42</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='orderby']</value>
      <webElementGuid>f07790e1-7953-4d89-bec3-6db4919d9d87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/div/form/select</value>
      <webElementGuid>77fd9ad1-3b8b-42b1-8eab-ebee53b4ff84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='armchairs'])[1]/following::select[1]</value>
      <webElementGuid>79377586-3f52-41eb-ba31-015496afc4e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cane bamboo chair'])[1]/following::select[1]</value>
      <webElementGuid>eb1bedc8-72e3-40ed-b32f-0fa14bbfa508</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bamboo natural multicolour armchairs mudda chair set of 2 for living room outdoor xl size'])[1]/preceding::select[1]</value>
      <webElementGuid>c8cbef54-0ffe-4d5a-bb48-734df31989ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::select[1]</value>
      <webElementGuid>0bcbe2a9-4b4b-4be7-918a-abb25ec545ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>5df3c008-d1aa-47c8-9d55-486b50049409</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'orderby' and (text() = '
					Sort by popularity
					Sort by average rating
					Sort by latest
					Sort by price: low to high
					Sort by price: high to low
			' or . = '
					Sort by popularity
					Sort by average rating
					Sort by latest
					Sort by price: low to high
					Sort by price: high to low
			')]</value>
      <webElementGuid>467bbe5d-f1c0-40b5-950b-e7eca771a301</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
