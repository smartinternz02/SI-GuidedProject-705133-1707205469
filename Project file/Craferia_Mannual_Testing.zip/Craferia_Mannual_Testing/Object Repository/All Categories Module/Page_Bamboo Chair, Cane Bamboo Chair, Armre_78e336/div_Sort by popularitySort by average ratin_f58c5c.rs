<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Sort by popularitySort by average ratin_f58c5c</name>
   <tag></tag>
   <elementGuidId>9c0926aa-cc6f-45d2-a006-a7d6ce3936f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.storefront-sorting</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3529d853-b310-4cd4-b2c5-01a2640b393f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>storefront-sorting</value>
      <webElementGuid>e80e23c6-bf21-4634-b031-845b7c510d3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	
					Sort by popularity
					Sort by average rating
					Sort by latest
					Sort by price: low to high
					Sort by price: high to low
			
	
	

	Showing all 4 results
</value>
      <webElementGuid>4b1621c8-af65-498d-89d4-838b46be059f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/div[@class=&quot;storefront-sorting&quot;]</value>
      <webElementGuid>943f2aff-1ecf-46bc-8209-9fd6d53d27dd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/div</value>
      <webElementGuid>9f8339ae-a814-4e53-b064-f537b39f0e0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='armchairs'])[1]/following::div[1]</value>
      <webElementGuid>e924b7d3-8997-4238-b145-8ef3fdf020ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cane bamboo chair'])[1]/following::div[1]</value>
      <webElementGuid>1eb2235d-c1d7-4f6e-9c67-a98961e73243</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bamboo natural multicolour armchairs mudda chair set of 2 for living room outdoor xl size'])[1]/preceding::div[2]</value>
      <webElementGuid>7e3cc8b8-f38b-4539-af4d-acbc737299c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::div[2]</value>
      <webElementGuid>2bd70c95-4c9d-4bf5-9cd9-1a06fedbea04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div</value>
      <webElementGuid>59452abd-93a8-40d8-a5d0-df667626c009</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
	
					Sort by popularity
					Sort by average rating
					Sort by latest
					Sort by price: low to high
					Sort by price: high to low
			
	
	

	Showing all 4 results
' or . = '
	
					Sort by popularity
					Sort by average rating
					Sort by latest
					Sort by price: low to high
					Sort by price: high to low
			
	
	

	Showing all 4 results
')]</value>
      <webElementGuid>bf89aed7-5b31-40ce-b2ce-77ed3305a86e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
