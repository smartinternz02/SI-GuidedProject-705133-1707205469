<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Hotel  Restaurant Furniture</name>
   <tag></tag>
   <elementGuidId>d5018525-062c-4393-b576-46d2aeda7852</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.woocommerce-products-header__title.page-title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>fa218546-e3bd-422b-b058-7eba3bda667f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-products-header__title page-title</value>
      <webElementGuid>f61da883-a3a8-401a-a5bc-3e6f06b5854e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Hotel &amp; Restaurant Furniture</value>
      <webElementGuid>a84aef79-d3c3-46b1-a809-c4afbd723a22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/h1[@class=&quot;woocommerce-products-header__title page-title&quot;]</value>
      <webElementGuid>0ddbbb59-f9be-443e-a129-3c3e5853fe80</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/h1</value>
      <webElementGuid>8ec0f0b4-0f36-46f0-aec8-c0cf2f69d73e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::h1[1]</value>
      <webElementGuid>e1d34f2e-43b4-4ed1-a02d-88b342d14873</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Handicrafts'])[1]/following::h1[1]</value>
      <webElementGuid>f8337176-02f1-45b4-b25a-2b6778c3d59b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::h1[1]</value>
      <webElementGuid>f5cdfb1c-36e6-423e-8c03-abc6e0692582</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bamboo Red colour chair table set with armrest for balcony / outdoor'])[1]/preceding::h1[1]</value>
      <webElementGuid>6ffae8bb-9ff3-48d6-816f-f1ccb4ad09ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>9aeb1453-21d6-4cc8-92dd-d0a1c3d358c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Hotel &amp; Restaurant Furniture' or . = 'Hotel &amp; Restaurant Furniture')]</value>
      <webElementGuid>5da651c3-d00b-4168-b5bd-7d6e15f58f51</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
