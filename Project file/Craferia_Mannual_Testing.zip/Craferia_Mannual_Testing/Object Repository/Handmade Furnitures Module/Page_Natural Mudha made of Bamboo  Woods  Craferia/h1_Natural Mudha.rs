<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Natural Mudha</name>
   <tag></tag>
   <elementGuidId>8cd619a9-b3c0-4c8a-8aac-fb02ff8dafe4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.woocommerce-products-header__title.page-title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>9fee3990-ca35-481c-83d0-1a8e12783469</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-products-header__title page-title</value>
      <webElementGuid>b697a5d1-a891-44c1-a90e-7764aeb83803</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Natural Mudha</value>
      <webElementGuid>39ae43e5-c66f-49b0-ad78-9e4c3202bc18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/h1[@class=&quot;woocommerce-products-header__title page-title&quot;]</value>
      <webElementGuid>030b599c-1f4c-4c55-a796-244eba7fb102</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/h1</value>
      <webElementGuid>bf462662-03a1-42fa-a2ab-07d42fb4e554</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::h1[1]</value>
      <webElementGuid>bd4972d0-aa88-42ed-a352-03b884df2f30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Handmade Furnitures'])[3]/following::h1[1]</value>
      <webElementGuid>b81ba3e0-e526-4046-b19c-864f8720329b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Natural Bamboo Mudha/mudda stools for indoor and outdoor (large size)set of 2'])[1]/preceding::h1[1]</value>
      <webElementGuid>a0d364cb-85ea-41dc-84c3-270b48d94786</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::h1[1]</value>
      <webElementGuid>ec0f7d10-aa11-4152-973a-955826446460</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>977008f7-4ce1-4d62-8d9a-6aaf16e718e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Natural Mudha' or . = 'Natural Mudha')]</value>
      <webElementGuid>de5e185c-4d4b-40a3-a6a2-9978d60dd708</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
