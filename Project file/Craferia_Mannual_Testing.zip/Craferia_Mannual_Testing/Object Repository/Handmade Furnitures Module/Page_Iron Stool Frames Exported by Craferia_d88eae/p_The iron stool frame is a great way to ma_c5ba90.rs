<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_The iron stool frame is a great way to ma_c5ba90</name>
   <tag></tag>
   <elementGuidId>4ae6543b-6409-42a2-b4e4-b2bef628c569</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>7c532201-8532-4014-8c7f-1fa641a05513</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>The iron stool frame is a great way to make your home feel more modern and upscale. The iron frame is also lightweight, so it’s easy to move. The iron frame also comes in a variety of colors, so you can make your home look as unique as you want. The iron frame is also a great way to display art and other items on your walls. You can find a lot of different styles of stool frames, so you can easily find one that suits your taste.</value>
      <webElementGuid>abe478ce-a5e6-49ef-8be1-ab28071770d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>bedc4b04-47c4-4dba-8962-5fd4d654be83</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/div/p</value>
      <webElementGuid>c396397a-953c-412a-a924-900dafe06078</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Iron Stools Frame'])[3]/following::p[1]</value>
      <webElementGuid>4323e23e-2a84-4515-9648-e8d25d1e3245</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>9b10746e-20de-4da0-a169-f42654465210</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Handcrafted Mudda Stool Indian Traditional with Iron Frame Plastic rope'])[1]/preceding::p[3]</value>
      <webElementGuid>6cdad3e7-9fb8-4eab-ada6-45f786e619cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::p[3]</value>
      <webElementGuid>d34d1196-8dc9-4aeb-afc7-5ceeff08bba6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The iron stool frame is a great way to make your home feel more modern and upscale. The iron frame is also lightweight, so it’s easy to move. The iron frame also comes in a variety of colors, so you can make your home look as unique as you want. The iron frame is also a great way to display art and other items on your walls. You can find a lot of different styles of stool frames, so you can easily find one that suits your taste.']/parent::*</value>
      <webElementGuid>4082cf43-d590-4af5-ae6e-baaf8d510056</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/div/p</value>
      <webElementGuid>f8c2edba-3ace-42a9-a8c6-b991540d780e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'The iron stool frame is a great way to make your home feel more modern and upscale. The iron frame is also lightweight, so it’s easy to move. The iron frame also comes in a variety of colors, so you can make your home look as unique as you want. The iron frame is also a great way to display art and other items on your walls. You can find a lot of different styles of stool frames, so you can easily find one that suits your taste.' or . = 'The iron stool frame is a great way to make your home feel more modern and upscale. The iron frame is also lightweight, so it’s easy to move. The iron frame also comes in a variety of colors, so you can make your home look as unique as you want. The iron frame is also a great way to display art and other items on your walls. You can find a lot of different styles of stool frames, so you can easily find one that suits your taste.')]</value>
      <webElementGuid>0154e8eb-979d-4bc2-a860-8aba3b1212ee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
