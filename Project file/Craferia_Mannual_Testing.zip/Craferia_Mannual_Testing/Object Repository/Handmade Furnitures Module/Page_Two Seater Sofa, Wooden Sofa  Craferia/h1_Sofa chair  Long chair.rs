<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Sofa chair  Long chair</name>
   <tag></tag>
   <elementGuidId>723939f5-2795-4028-9e8d-811b5684248f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.woocommerce-products-header__title.page-title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>fbc30780-483e-4ce7-be38-a439a52fd502</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-products-header__title page-title</value>
      <webElementGuid>d75405f8-697e-466d-9ae3-849f8d01f0dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sofa chair / Long chair</value>
      <webElementGuid>11768395-2bcf-40d4-83e7-f16f0c4da409</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/h1[@class=&quot;woocommerce-products-header__title page-title&quot;]</value>
      <webElementGuid>dfa8ae60-22ba-4004-934b-b56257ff54b0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/h1</value>
      <webElementGuid>3f9d7103-9969-48ea-8422-e61b0964331f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::h1[1]</value>
      <webElementGuid>1aa3a57b-9bca-43e2-8f06-8c5630c65091</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Handmade Furnitures'])[3]/following::h1[1]</value>
      <webElementGuid>93ba43d3-a4d2-448e-89be-7bb1544e6b16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eco-friendly Bamboo Natural 3 Seater Chair/Bamboo Sofa 3 Seater for indoor outdoor'])[1]/preceding::h1[1]</value>
      <webElementGuid>e62fc050-4189-4c2d-b656-e36262de2de1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[2]/preceding::h1[1]</value>
      <webElementGuid>808bcc76-3b09-4bae-8061-ef99da1338f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>a15eee6d-8d94-4cbb-8295-1612e72b4e62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Sofa chair / Long chair' or . = 'Sofa chair / Long chair')]</value>
      <webElementGuid>b5c1ba84-8d13-4a6d-9ec3-991e4782e83d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
