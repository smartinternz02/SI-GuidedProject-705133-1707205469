<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Discover the beauty and reliability of Ca_8a762f</name>
   <tag></tag>
   <elementGuidId>792e46f2-9b2c-4312-ac0e-21d2f2da47dd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>67258a7b-5ee0-4bee-86f3-255d06eb1117</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Discover the beauty and reliability of Cane Furniture’s chair sofa set. Our cane furniture is crafted with care and made from high-quality materials that are built to last. Enjoy the timeless elegance and durability of our furniture, adding a touch of sophistication to your home or office space. With Cane Furniture, you can have both style and longevity in one package.</value>
      <webElementGuid>c691e43d-fe05-4ccb-a663-d43a6fbd377b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>a4bdf5c8-237d-4ca4-943d-e753ca613515</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/p</value>
      <webElementGuid>196637c1-9531-4e31-b543-8789e3ab30f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cane Furniture'])[3]/following::p[1]</value>
      <webElementGuid>68522a83-91a7-4938-a782-c28232b26c7e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::p[1]</value>
      <webElementGuid>5dd986c7-2b8c-41f0-9efb-4f820fce9b40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::p[3]</value>
      <webElementGuid>e225ce86-df70-4dc6-a0ac-26b61d734d79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FREE SHIPPING'])[1]/preceding::p[3]</value>
      <webElementGuid>0f8b4972-2371-4467-ae6e-0450eb5b2c30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Discover the beauty and reliability of Cane Furniture’s chair sofa set. Our cane furniture is crafted with care and made from high-quality materials that are built to last. Enjoy the timeless elegance and durability of our furniture, adding a touch of sophistication to your home or office space. With Cane Furniture, you can have both style and longevity in one package.']/parent::*</value>
      <webElementGuid>125e1796-9117-4f0a-8473-f407a81d37cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/p</value>
      <webElementGuid>5ac678aa-5609-4d1e-a5bc-65ebabb8f315</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Discover the beauty and reliability of Cane Furniture’s chair sofa set. Our cane furniture is crafted with care and made from high-quality materials that are built to last. Enjoy the timeless elegance and durability of our furniture, adding a touch of sophistication to your home or office space. With Cane Furniture, you can have both style and longevity in one package.' or . = 'Discover the beauty and reliability of Cane Furniture’s chair sofa set. Our cane furniture is crafted with care and made from high-quality materials that are built to last. Enjoy the timeless elegance and durability of our furniture, adding a touch of sophistication to your home or office space. With Cane Furniture, you can have both style and longevity in one package.')]</value>
      <webElementGuid>c386c5b5-9b28-4c9b-873d-d9babb20d975</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
