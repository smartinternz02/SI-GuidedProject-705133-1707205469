<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Pidha stools, or pidha chowki, are tradit_a9f772</name>
   <tag></tag>
   <elementGuidId>8c26c135-5935-462f-b62c-1e90408cb148</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>b8d68c69-0190-4593-92bb-472ed4c34bcc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pidha stools, or pidha chowki, are traditional wooden stools used in India for centuries. These stools come in a variety of shapes and sizes and are often intricately carved and decorated. Their design is quite distinct, featuring a flat top with four legs, sometimes with a fifth leg in the middle for additional support. Pidha stools are typically made of hardwood and designed to be stable, comfortable and durable.</value>
      <webElementGuid>9b9fc74b-c669-4f0d-8d4d-401438d1dfd9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>d3b08e3e-8f34-491c-9beb-8d3c9c5fc297</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/p</value>
      <webElementGuid>eb5e370b-3831-4f16-8d1b-3eaf8d0623ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pidha stools'])[3]/following::p[1]</value>
      <webElementGuid>6baa441d-073d-4a49-b1ec-146234571d09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>ac533b22-b93c-4ccb-bd6b-3ca62fa9eadb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::p[3]</value>
      <webElementGuid>ac983bdd-bfa2-4771-897d-b09d20808224</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FREE SHIPPING'])[1]/preceding::p[3]</value>
      <webElementGuid>39280745-48ae-4d74-9cc8-2d99c387402a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Pidha stools, or pidha chowki, are traditional wooden stools used in India for centuries. These stools come in a variety of shapes and sizes and are often intricately carved and decorated. Their design is quite distinct, featuring a flat top with four legs, sometimes with a fifth leg in the middle for additional support. Pidha stools are typically made of hardwood and designed to be stable, comfortable and durable.']/parent::*</value>
      <webElementGuid>610f80c7-f56a-424c-8fad-5b0777d21b51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/p</value>
      <webElementGuid>a1d9e971-3738-402d-ae5c-e6b891a439c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Pidha stools, or pidha chowki, are traditional wooden stools used in India for centuries. These stools come in a variety of shapes and sizes and are often intricately carved and decorated. Their design is quite distinct, featuring a flat top with four legs, sometimes with a fifth leg in the middle for additional support. Pidha stools are typically made of hardwood and designed to be stable, comfortable and durable.' or . = 'Pidha stools, or pidha chowki, are traditional wooden stools used in India for centuries. These stools come in a variety of shapes and sizes and are often intricately carved and decorated. Their design is quite distinct, featuring a flat top with four legs, sometimes with a fifth leg in the middle for additional support. Pidha stools are typically made of hardwood and designed to be stable, comfortable and durable.')]</value>
      <webElementGuid>0062757e-01ce-4fee-af33-3cb2b4cbaeb8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
