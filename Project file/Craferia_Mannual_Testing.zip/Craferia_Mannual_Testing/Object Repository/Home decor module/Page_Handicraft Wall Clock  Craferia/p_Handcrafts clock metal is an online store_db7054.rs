<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Handcrafts clock metal is an online store_db7054</name>
   <tag></tag>
   <elementGuidId>8e44c29c-18c8-41d4-b8c3-c328c460b8b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>c18f393a-237e-410c-86dd-f11ba8e41c25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Handcrafts clock metal is an online store that offers the latest antique-styled wall and table clocks. They come in a variety of trendy designs that will add grace to any room in your home or office. Get them at the cheapest price today.</value>
      <webElementGuid>0464eb1f-1009-499e-bcbb-5289ada4d039</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>3c3df2ee-f449-45a0-9f5f-c146a550b453</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/div/p</value>
      <webElementGuid>b80d1168-4c6f-454a-a633-3fd83f6fe8f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clock'])[3]/following::p[1]</value>
      <webElementGuid>83b3d133-9a9a-44b2-b03a-3fefe918a72b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>8d41a018-5469-4f23-b3b0-8540c2b76a28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::p[2]</value>
      <webElementGuid>d89410a3-beb3-4826-9ec9-349c34f86188</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OFF'])[1]/preceding::p[2]</value>
      <webElementGuid>1b9d9c6c-566e-4fff-923e-be291b77f26e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Handcrafts clock metal is an online store that offers the latest antique-styled wall and table clocks. They come in a variety of trendy designs that will add grace to any room in your home or office. Get them at the cheapest price today.']/parent::*</value>
      <webElementGuid>a6dacffc-7d07-43dc-a1e6-f5e84dcf61b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/div/p</value>
      <webElementGuid>82f80619-1a8a-4f70-9a9d-544c77e04d70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Handcrafts clock metal is an online store that offers the latest antique-styled wall and table clocks. They come in a variety of trendy designs that will add grace to any room in your home or office. Get them at the cheapest price today.' or . = 'Handcrafts clock metal is an online store that offers the latest antique-styled wall and table clocks. They come in a variety of trendy designs that will add grace to any room in your home or office. Get them at the cheapest price today.')]</value>
      <webElementGuid>59da633e-bfa9-4fae-83fb-f0730e09fe6b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
