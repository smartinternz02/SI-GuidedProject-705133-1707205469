<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_A key holder is an efficient and elegant _f0cd47</name>
   <tag></tag>
   <elementGuidId>c5984486-ee76-4835-8205-9cfbd6149ae2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>7d356314-04e5-49af-8f60-c6c4e2897794</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>A key holder is an efficient and elegant way to store your keys. Made with metal, this key holder will last for years to come and will make a wonderful addition to any home. The metal key holder makes a great gift idea for a friend or family member. They have 100+ designs available with showpiece decor as well. Each design represents Indian culture and the natural beauty of the country.</value>
      <webElementGuid>c4f20eb3-4818-4932-8fc5-53f15d1060d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>0f33ea11-10d6-4931-acb8-9f29becd9172</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/div/p</value>
      <webElementGuid>af6187e5-765f-4f8c-9ece-7ced64774f79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Key Holders'])[3]/following::p[1]</value>
      <webElementGuid>33c27cb2-3559-4a74-bc9e-854dede374c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>f3e33344-8de5-41bc-bf3d-5e3558c9c3d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::p[2]</value>
      <webElementGuid>e48a4d32-19d2-4c2d-a94a-60567a4c1398</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Beautiful Key Holder for Home Decor/Office Decor (Buddha Head with Leaf Keyholder)'])[1]/preceding::p[2]</value>
      <webElementGuid>ab3b4bb8-bb7e-44b8-a121-b19c301060e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='A key holder is an efficient and elegant way to store your keys. Made with metal, this key holder will last for years to come and will make a wonderful addition to any home. The metal key holder makes a great gift idea for a friend or family member. They have 100+ designs available with showpiece decor as well. Each design represents Indian culture and the natural beauty of the country.']/parent::*</value>
      <webElementGuid>bf71bdc6-afd4-405f-92bd-21a4b1d35817</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/div/p</value>
      <webElementGuid>e86daf73-cc4b-420b-8f1f-cfd333b254a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'A key holder is an efficient and elegant way to store your keys. Made with metal, this key holder will last for years to come and will make a wonderful addition to any home. The metal key holder makes a great gift idea for a friend or family member. They have 100+ designs available with showpiece decor as well. Each design represents Indian culture and the natural beauty of the country.' or . = 'A key holder is an efficient and elegant way to store your keys. Made with metal, this key holder will last for years to come and will make a wonderful addition to any home. The metal key holder makes a great gift idea for a friend or family member. They have 100+ designs available with showpiece decor as well. Each design represents Indian culture and the natural beauty of the country.')]</value>
      <webElementGuid>09215e49-60f0-4f8d-a1ff-5e38ad2bd590</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
