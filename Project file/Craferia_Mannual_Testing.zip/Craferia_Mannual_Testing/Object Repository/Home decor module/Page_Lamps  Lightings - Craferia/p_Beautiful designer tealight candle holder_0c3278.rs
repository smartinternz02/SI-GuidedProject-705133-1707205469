<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Beautiful designer tealight candle holder_0c3278</name>
   <tag></tag>
   <elementGuidId>9a16b2e5-e3d4-47e6-95ac-c21e65b85d0d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>06fbec42-0cdf-40ee-8b43-c716eb29f797</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Beautiful designer tealight candle holder is a perfect gift for your loved ones. The metal handcrafted product is made of pure copper that is sturdy and luxurious at the same time. The design is eye-catching and will add a special touch to your living room.</value>
      <webElementGuid>54956a99-5b98-4ab0-9806-8fb5e973ab2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>46e50343-eb63-46f7-a5a4-dba0b46a6ea2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/div/p</value>
      <webElementGuid>e5d134fc-5e08-4b2c-a214-401129323703</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lamps &amp; Lightings'])[3]/following::p[1]</value>
      <webElementGuid>75ba7003-65c8-495a-8b4b-2605273c5a91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>43a728cf-61f9-4ffc-ab89-d96833adb2ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='→'])[1]/preceding::p[2]</value>
      <webElementGuid>5d0b5ce4-6489-4095-aeb2-375de6537652</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Load Krishna Designe Tea Light Candle Holder For Diwali Decorations'])[1]/preceding::p[2]</value>
      <webElementGuid>d04977c8-1ee4-437a-904d-f6b638a91d13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Beautiful designer tealight candle holder is a perfect gift for your loved ones. The metal handcrafted product is made of pure copper that is sturdy and luxurious at the same time. The design is eye-catching and will add a special touch to your living room.']/parent::*</value>
      <webElementGuid>2155f632-52ac-4bf0-b4fc-c6a48d499585</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/div/p</value>
      <webElementGuid>97548dd2-ab6b-4196-b097-571e9aa8998a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Beautiful designer tealight candle holder is a perfect gift for your loved ones. The metal handcrafted product is made of pure copper that is sturdy and luxurious at the same time. The design is eye-catching and will add a special touch to your living room.' or . = 'Beautiful designer tealight candle holder is a perfect gift for your loved ones. The metal handcrafted product is made of pure copper that is sturdy and luxurious at the same time. The design is eye-catching and will add a special touch to your living room.')]</value>
      <webElementGuid>b8d98c60-d3a3-4a9d-915e-45d1b24ec080</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
