<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Diffuser is perfect for all your home nee_93d880</name>
   <tag></tag>
   <elementGuidId>22be09ff-5484-468c-8700-f7cbd31a99f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>bd334e5f-5377-482e-97cd-0321fe09d15a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.</value>
      <webElementGuid>ad44f93d-44e6-4e4f-b182-96912a8b02ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>eaff30ef-e74c-408e-b7d1-feed6dbc4515</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/div/p</value>
      <webElementGuid>dbed9a4b-ac08-4239-9157-74892dd6ab0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home Accents'])[3]/following::p[1]</value>
      <webElementGuid>121429c3-10f0-49fe-b215-e923da27a8d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>5f5b7aa9-828f-45a4-a905-2752f02be4d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OFF'])[1]/preceding::p[2]</value>
      <webElementGuid>b5c8a97e-9acd-4b9f-9085-f3f173a6069d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SALE'])[1]/preceding::p[2]</value>
      <webElementGuid>54d84bad-edaa-4514-92d0-a41924a02773</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.']/parent::*</value>
      <webElementGuid>c15170b6-e018-42aa-8d6d-a1fbf9917fae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/div/p</value>
      <webElementGuid>c705ec81-5542-4410-9652-0352f462f0d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.' or . = 'Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.')]</value>
      <webElementGuid>2b0a9b9b-c2e4-419a-b2d4-bb1f2159a29e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
