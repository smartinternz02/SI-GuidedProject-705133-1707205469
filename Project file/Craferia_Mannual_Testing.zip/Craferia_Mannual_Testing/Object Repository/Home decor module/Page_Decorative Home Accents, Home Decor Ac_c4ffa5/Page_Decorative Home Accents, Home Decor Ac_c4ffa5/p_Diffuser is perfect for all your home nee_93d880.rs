<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Diffuser is perfect for all your home nee_93d880</name>
   <tag></tag>
   <elementGuidId>24d5683b-449d-4cdf-b6e0-4d68cd8a16ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/header/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.term-description > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>8620b5da-71a2-4f21-b9f4-cf2b79ed8e13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.</value>
      <webElementGuid>e696219f-6315-4b7d-ac81-c29f078edc2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/header[@class=&quot;woocommerce-products-header&quot;]/div[@class=&quot;term-description&quot;]/div[@class=&quot;term-description&quot;]/p[1]</value>
      <webElementGuid>fbbbfc56-2ed0-4ca6-9786-e2922febcf08</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/header/div/div/p</value>
      <webElementGuid>b3c3a313-e1bc-493c-b91b-312739e59c35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home Accents'])[3]/following::p[1]</value>
      <webElementGuid>b2393b79-ddb5-4603-a763-e0eb7fbc7a76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::p[1]</value>
      <webElementGuid>2c1aaf26-495c-49a1-a5f7-596a19e75a5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OFF'])[1]/preceding::p[2]</value>
      <webElementGuid>1345dde7-e8f3-4bcb-8cff-ad0b09027c3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SALE'])[1]/preceding::p[2]</value>
      <webElementGuid>df128572-799d-4682-875e-27607f077569</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.']/parent::*</value>
      <webElementGuid>27367eca-1a99-4a60-91f7-62912e547fa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header/div/div/p</value>
      <webElementGuid>f243525b-44f2-4cc1-b533-a7b23f3049f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.' or . = 'Diffuser is perfect for all your home needs. It is made of ceramic and electric with vintage granite white color. This diffuser is perfect for dining room, living room, bedroom, kitchen, bathroom and other places where you need natural smell diffusion. The ceramic diffuser will not heat up like other diffusers and will not flow dangerous fumes around your room.')]</value>
      <webElementGuid>c4ede6c4-9821-4615-8f18-291a21bd4114</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
