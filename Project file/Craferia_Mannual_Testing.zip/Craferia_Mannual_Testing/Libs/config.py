# Craferia automation web server

CRAFERIA_HOST = 'www.craferia.com/my-account'

# UI page loading timeout setting
UI_TIMEOUT = 30

